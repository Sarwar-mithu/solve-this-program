
package other_technique06;


public class WrapperPrimitiveToString03 {
    public static void main(String[] args) {
        
           //String to primitive
        String s = "32";
        int i = Integer.parseInt(s); //double,char,
        System.out.println("I : "+i);
        
        System.out.println("\n\n");
        
        int a = Integer.valueOf(s);
        System.out.println("A : "+a);
    }
    
}
