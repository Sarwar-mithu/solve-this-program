
package other_technique06;


public class WrapperClassStringToPrimitive02 {
    public static void main(String[] args) {
        
        // primitive to String
        int i = 14;
        String s = Integer.toString(i); //Double,Boolean,Charcter
        System.out.println("I : "+s);
        
        System.out.println("\n\n");
        
        
     
        
        
        
    }
    
}
