
package other_technique06;


public class WrapperClass01 {
    public static void main(String[] args) {
        
        //primitive -> objecet
        
        int x = 30;
        Integer y = Integer.valueOf(x);
        System.out.println("Y : "+y);
        Integer z = x; // autoboxing
        System.out.println("Z : "+z);
        
        System.out.println("\n\n");
        
        // object -> primitive
        Double d = new Double(11.22);
        System.out.println("d : "+d);
        
        double e = d.doubleValue();
        System.out.println("E : "+e);
        
        double g = d; //unboxing
        System.out.println("G : "+g);
    }
}
