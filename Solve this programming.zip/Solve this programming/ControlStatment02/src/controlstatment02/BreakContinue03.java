
package controlstatment02;


public class BreakContinue03 {
    
    public static void main(String[] args) {
        for(int i=1;i<=100;i++){
            if(i==10){
                break;
            }
            System.out.println(i+" Bangladesh");
        }
    }
    
}
