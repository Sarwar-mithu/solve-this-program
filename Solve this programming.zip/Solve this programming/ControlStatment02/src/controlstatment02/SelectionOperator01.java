
package controlstatment02;
import java.util.Scanner;

public class SelectionOperator01 {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num;
        System.out.print("Enter any Integer : ");
        num = input.nextInt();
        
        if(num>0){
            System.out.println(num+" is Positive");
        }
        else if(num<0){
            System.out.println(num+" is Nagative");
        }
        else{
            System.out.println(" equel to zero");
        }
    }
    
}
