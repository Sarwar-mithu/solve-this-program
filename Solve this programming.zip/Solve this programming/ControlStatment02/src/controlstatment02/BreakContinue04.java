
package controlstatment02;


public class BreakContinue04 {
    public static void main(String[] args) {
        for(int i=1;i<=15;i++){
            if(i==10){
                continue;   //jar sathe match korbe sei man print korbe na,baki sob gulo print korbe
            }
            System.out.println(i+" Bangladesh");
        }
    }
    
}
