
package abstraction05.abstract01;


public class Test {
    public static void main(String[] args) {
        
        MobileUser ms;
        ms = new Sajada();
        ms.call();
        ms.sendMessage();
        
        ms = new Taher();
        ms.call();
        ms.sendMessage();
    }
    
}
