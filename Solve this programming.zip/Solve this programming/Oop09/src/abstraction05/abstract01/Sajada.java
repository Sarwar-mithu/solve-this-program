
package abstraction05.abstract01;


public class Sajada extends MobileUser{
    
    @Override
    void sendMessage(){
        System.out.println("Hi!! i am sajada akther");
        System.out.println();
    }
}
