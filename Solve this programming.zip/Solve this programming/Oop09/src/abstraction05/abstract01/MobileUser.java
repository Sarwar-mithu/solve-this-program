
package abstraction05.abstract01;
/*
1st: sodhu abastract method call di ta hole 100%
2nd: jodi normal method ekai sathe rakhi ta hole 100% hobe na
*/

abstract public class MobileUser {
    
    // non method o call dite pari 
    
    void call(){
        System.out.println("Text message");
    }
    
   abstract void sendMessage();//abstract method
    
}
