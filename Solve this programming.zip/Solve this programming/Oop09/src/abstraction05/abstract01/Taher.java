
package abstraction05.abstract01;


public class Taher extends MobileUser {
    
    @Override
    void sendMessage(){
        System.out.println("Hi!! i am Abu Taher");
    }
    
}
