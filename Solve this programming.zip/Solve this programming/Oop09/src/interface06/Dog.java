
package interface06;


public class Dog implements Animal{
    public void eat(){
        System.out.println("Doges can eat egg ");
        System.out.println();
    }
    
}



