/*
1st: class -> class hoy ta hole extends korbo
2nd:interface-> interface hoy ta hole extends korbo
3rd: interface -> class hoy ta hole  implements korbo
*/
package interface06;


public interface Animal {
    
  public abstract void eat();  
}


