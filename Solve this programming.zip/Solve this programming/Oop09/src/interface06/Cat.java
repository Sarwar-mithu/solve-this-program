
package interface06;


public class Cat implements Animal {
    public void eat(){
        System.out.println("Cats can eat meat");
    }
}

