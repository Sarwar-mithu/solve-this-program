
package method_overriding03;
/*
1st: same name dibo, return typeo same dibo
2nd: coder serial r pashe ekta symbol dekabe 
3rd: Symbol r upor click korbo 
4th: add to @override annotaion click korbo
*/

public class Teacher extends Person {
    
    String qualification;
    
    
    @Override
    void displayInformation(){
        System.out.println("Teacher name : "+name);
        System.out.println("Teacher age : "+age);
        System.out.println("T-Qualification : "+qualification);
        System.out.println();
        
    }
    
}
