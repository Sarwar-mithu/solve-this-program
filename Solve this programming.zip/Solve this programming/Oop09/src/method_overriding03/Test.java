
package method_overriding03;


public class Test {
    public static void main(String[] args) {
        
        Teacher t1 = new Teacher();
        t1.name = "Sarwar mithu";
        t1.age = 25;
        t1.qualification = "BSC in CSE";
        t1.displayInformation();
        
        
        Person p1 = new Person();
        p1.name = "Abu Taher";
        p1.age = 56;
        p1.displayInformation();
      
    }
}
