
package inheritance02.inheritance01.inheritance002;


public class Student extends Person {
    
    private String qualification;

    public String getQualification() {
        return qualification;
    }

    public void setQualification(String qualification) {
        this.qualification = qualification;
    }
    
    void displayInformation2(){
        displayInformation1();
        System.out.println("Qualification : "+getQualification());
        System.out.println();
    }
}
