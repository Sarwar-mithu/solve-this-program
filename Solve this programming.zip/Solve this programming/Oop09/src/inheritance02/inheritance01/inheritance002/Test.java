
package inheritance02.inheritance01.inheritance002;


public class Test {
    public static void main(String[] args) {
        
        Student s1 = new Student();
        
        s1.setName("Sarwar mithu");
        s1.setAge(25);
        s1.setQualification("BSC in CSE");
        s1.displayInformation2();
        
        
        Student s2 = new Student();
        
        s2.setName("Abu Salman");
        s2.setAge(22);
        s2.setQualification("BSC in CSE");
        s2.displayInformation2();
    }
    
}
