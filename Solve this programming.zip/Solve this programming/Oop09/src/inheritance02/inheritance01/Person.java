
package inheritance02.inheritance01;


public class Person {
    
    String name,gender;
    int id,phone;
    static String universityName = "Eastern University";
    
    void displayInformation1(){
        
        System.out.println("University: "+universityName);
        System.out.println("Stu-name: "+name);
        System.out.println("Stu-id  : "+id);
        System.out.println("Gender  : "+gender);
        System.out.println("Phone   : "+phone);
        
    }
    
}
