
package inheritance02.inheritance01;


public class Test {
    public static void main(String[] args) {
        
        Teacher t1 = new Teacher();
        
        t1.name = "Sarwar mithu";
        t1.id = 497192;
        t1.qualification = "BSC in CSE";
        t1.gender = "Male";
        t1.phone = 1964626938;
        t1.displayInformation2();
        
        
        Teacher t2 = new Teacher();
        
        t2.name = "Mithu Sarwar";
        t2.id = 497192;
        t2.qualification = "BSC in CSE";
        t2.gender = "Male";
        t2.phone = 163410020;
        t2.displayInformation2();
    }
    
}
