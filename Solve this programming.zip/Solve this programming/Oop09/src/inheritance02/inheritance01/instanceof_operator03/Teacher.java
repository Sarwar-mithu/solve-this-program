
package inheritance02.inheritance01.instanceof_operator03;


public class Teacher extends Person{
    
}
