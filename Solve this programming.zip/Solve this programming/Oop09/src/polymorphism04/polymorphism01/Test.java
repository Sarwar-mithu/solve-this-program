
package polymorphism04.polymorphism01;


public class Test {
    public static void main(String[] args) {
        
        Person p = new Person();
        p.name = "Abu Taher";
        p.age = 60;
        p.displayInformation();
        
        
        p = new Teacher();
        p.name = "Sajada Akther";
        p.age = 55;
        //p.qualification = "BSC in CSE";
        p.displayInformation();
    }
    
}
