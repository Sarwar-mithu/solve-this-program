
package interface_Support_Mulitple_Inheritance07;


public class C implements A,B {
    public void play(){
        System.out.println("Hello, i am form C ");
    }
    
}
