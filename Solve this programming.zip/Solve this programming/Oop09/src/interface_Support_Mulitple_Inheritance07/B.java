
package interface_Support_Mulitple_Inheritance07;

public interface B {
    void play();
}
