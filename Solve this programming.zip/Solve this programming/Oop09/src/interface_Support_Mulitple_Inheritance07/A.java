
package interface_Support_Mulitple_Inheritance07;


public interface A {
    void play();
}
