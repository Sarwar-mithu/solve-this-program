
package interface_Support_Mulitple_Inheritance07;


public class Test {
    public static void main(String[] args) {
        
        C ob = new C();
        ob.play();
    }
    
}

