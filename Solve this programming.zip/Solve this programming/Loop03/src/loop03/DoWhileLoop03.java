
package loop03;

public class DoWhileLoop03 {
    public static void main(String[] args) {
        
        int i = 1;
        do{
            System.out.println(i+" Bangladesh");
            i++;
        }while(i<=10);
    }
    
}
