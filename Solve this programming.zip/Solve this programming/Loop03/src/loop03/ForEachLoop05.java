
package loop03;


public class ForEachLoop05 {
    
    public static void main(String[] args) {
        /*String[] names = {"Taher","Sajada","Mehedi","Mithu","Salman"};
        
        
        for (String x : names) { // for each loop
            System.out.println(x);  
        }*/
        
        int[] num = {2,3,4,5,6,7};
        int sum = 0;
        
        for(int m : num){
            System.out.println(m);
        }
    }
    
}
