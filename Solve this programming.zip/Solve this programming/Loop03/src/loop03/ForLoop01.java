
package loop03;


public class ForLoop01 {
    public static void main(String[] args) {
        for(int i=1;i<=10;i++){
            System.out.println(i+" Bangladesh");
        }
        
        for(int i = 2;i<=10;i = i+2){
            System.out.println("Even number : "+i);
        }
        
        //Decriment
        for(int i=10;i>=1;i--){
            System.out.println(i+" Decriment");
        }
            
    }
    
}
