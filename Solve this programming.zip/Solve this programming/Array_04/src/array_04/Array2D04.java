
package array_04;
import java.util.Scanner;

public class Array2D04 {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        
        //A input
        int num1,num2;
        
        System.out.print("How many Row for A matrix : ");
        num1 = input.nextInt();
        System.out.print("How many Column for A matrix : ");
        num2 = input.nextInt();
        
        int[][] A = new int[num1][num2];
        
        System.out.println("Enter elements for A matrix :");
        for (int row = 0; row < num1; row++) {
            for (int col = 0; col < num2; col++) {
                System.out.printf("A[%d][%d]=",row,col);
                A[row][col] = input.nextInt();
            }
        }
        
        //B input
        int num3,num4;
        System.out.print("How many Row for B matrix :");
        num3 = input.nextInt();
        System.out.print("How many Column for B matrix :");
        num4 = input.nextInt();
        
        int[][] B = new int[num3][num4];
        System.out.println("Enter elements for B matrix : ");
        for (int row = 0; row < num3; row++) {
            for (int col = 0; col < num4; col++) {
                System.out.printf("A[%d][%d]=",row,col);
                B[row][col]= input.nextInt();
            }
        }
        
        //output
        System.out.print("A = ");
        for (int row = 0; row < num1; row++) {
            for (int col = 0; col < num2; col++) {
                System.out.print("\t "+A[row][col]);
            }
            System.out.println();
        }
        
        System.out.println("\n");
        
        System.out.print("B =");
        for (int row = 0; row < num3; row++) {
            for (int col = 0; col < num4; col++) {
                System.out.print("\t "+B[row][col]);
            }
            System.out.println();
        }
        
        System.out.println("\n");
        
        // sum
        
        System.out.print("A+B = ");
        for (int row = 0; row < 2; row++) {
            for (int col = 0; col < 3; col++) {
                System.out.print("\t "+(A[row][col]+B[row][col]));
            }
            System.out.println();
        }
        
    }
    
}
