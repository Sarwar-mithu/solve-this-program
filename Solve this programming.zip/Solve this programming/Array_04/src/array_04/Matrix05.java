
package array_04;
import java.util.Scanner;

public class Matrix05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int[][] A = new int[3][3];
        int sumOfDiagonal = 0;
        int sumOfUpperElements = 0;
        int sumOfLowerElements = 0;
        //matrix input
        System.out.println("Enter matrix : ");
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                A[row][col] = input.nextInt();
            }
        }
        
        //sum of diagonal,upper triangle, lower triangle
        
        for (int row = 0; row < 3; row++) {
            for (int col = 0; col < 3; col++) {
                if(row==col){
                    sumOfDiagonal = sumOfDiagonal +A[row][col];
                }
                if(row<col){
                    sumOfUpperElements = sumOfUpperElements + A[row][col];
                }
                if(row>col){
                    sumOfLowerElements = sumOfLowerElements + A[row][col];
                }
            }
        }
            System.out.println("Sum of diagonal elements : "+sumOfDiagonal);
            System.out.println("Sum of Upper elements : "+sumOfUpperElements);
            System.out.println("Sum of Lower elements : "+sumOfLowerElements);
    }
}
