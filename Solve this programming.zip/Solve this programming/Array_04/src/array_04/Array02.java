
package array_04;

import java.util.Scanner;


public class Array02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num;
        System.out.print("How many array : ");
        num = input.nextInt();
        
        double[] number = new double[num];
        double sum = 0;
        
        //input
        System.out.print("Please enter any number : ");
        for (int i = 0; i < num; i++) {
            number[i] = input.nextDouble();
        }
        
        //output
        for (int j = 0; j < num; j++) {
           sum = sum + number[j]; 
        }
        System.out.println("Length = "+number.length);
        System.out.println("Sum is : "+sum);
        double avg = sum/number.length;
        System.out.println("Average is : "+avg);
        
        //maximum
        double max = number[0];
        for (int x = 0; x < num; x++) {
            if(max<number[x]){
                max = number[x];
            }
        }
        System.out.println("Maximum Number : "+max);
        
        //minimum
        double min = number[0];
        for (int y = 0; y < num; y++) {
            if(min>number[y]){
                min = number[y];
            }
        }
        System.out.println("Minimum Number : "+min);
    }
    
}
