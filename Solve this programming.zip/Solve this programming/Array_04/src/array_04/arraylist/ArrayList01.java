/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package array_04.arraylist;

import java.util.ArrayList;
import java.util.Iterator;


public class ArrayList01 {
     public static void main(String[] args) {
        ArrayList<Integer> number = new ArrayList<Integer>();
        
        //adding elements
        number.add(10);
        number.add(20);
        number.add(30);
        number.add(3, 40);
        
        //System.out.println(number);
        /*
        //for each loop print
        for(int x : number){
            System.out.print(" "+x);
        }
        System.out.println();
    */
        Iterator itr = number.iterator();
        while(itr.hasNext()){
            System.out.print(" "+itr.next());
        }
        System.out.println();
        System.out.println("Size = "+number.size());
    }

}
