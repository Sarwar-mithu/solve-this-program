
package array_04.arraylist;

import java.util.ArrayList;


public class ArrayList03 {
    public static void main(String[] args) {
        ArrayList<Integer> number = new ArrayList<>();
        
        number.add(10);
        number.add(20);
        number.add(30);
        number.add(3, 40);
        
        System.out.print(number);
        System.out.println();
        System.out.println("Size = "+number.size());
        
        //number.clear();
        boolean check = number.isEmpty();
        System.out.println("Arraylist empty : "+check);
        
        boolean contain = number.contains(30);
        System.out.println("30 in in the list : "+contain);
        
        int pos = number.indexOf(40);
        System.out.println("Index of 40 is : "+pos);
        
        number.set(3, 70);
        System.out.println("After setting : "+number);
        
        int x = number.get(0);
        System.out.println("Index 0 : "+x);
        
    }
            
    
}
