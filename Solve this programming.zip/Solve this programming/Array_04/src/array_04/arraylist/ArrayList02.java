
package array_04.arraylist;

import java.util.ArrayList;



public class ArrayList02 {
    public static void main(String[] args) {
        
        ArrayList<Integer> number = new ArrayList<>();
        
       number.add(10);
       number.add(20);
       number.add(30);
       number.add(3, 40);
     
       for( int x : number){
           System.out.print(" "+x);
       }
        System.out.println();
        System.out.print("Size = "+number.size());
        
        System.out.println("\n\n");
        //Removing
        number.remove(3);
        System.out.print("After Removing Elements : "+number);
        System.out.println();
        System.out.println("After Removing size : "+number.size());
        
        System.out.println("\n");
        
        //all removing
        number.removeAll(number);
        System.out.print("Remove all = "+number);
        System.out.println();
        System.out.println("Size + "+number);
                
    }
    
}
