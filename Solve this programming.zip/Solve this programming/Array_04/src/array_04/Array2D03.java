
package array_04;
import java.util.Scanner;
 
public class Array2D03 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1,num2;
        System.out.print("How many Row   A : ");
        num1 = input.nextInt();
        System.out.print("How many Colmun A: ");
        num2 = input.nextInt();
        
       
        int[][] A = new int[num1][num2];
        
        System.out.println("Enter element for A matrix : ");
        for (int row = 0; row < num1; row++) {
            for (int col = 0; col < num2; col++) {
                System.out.printf("A[%d][%d]=",row,col);
                A[row][col] = input.nextInt();
            }
            
        }
        int num3,num4;
        System.out.print("How many Row B :");
        num3 = input.nextInt();
        System.out.print("How many Colmun B :");
        num4 = input.nextInt();
        int[][] B= new int[num3][num4];
        
        System.out.println("Enter elemant for B matrix : ");
        for (int row = 0; row < num3; row++) {
            for (int col = 0; col < num4; col++) {
                System.out.printf("B[%d][%d]=",row,col);
                B[row][col] = input.nextInt();
            }
        }
        
        //output
        System.out.print(" A = ");
        for (int row = 0; row < num1; row++) {
            for (int col = 0; col < num2; col++) {
                System.out.print("\t "+A[row][col]);
            }
            System.out.println();
        }
        
        System.out.println("\n");
        
        System.out.print(" B = ");
        for (int row = 0; row < num3; row++) {
            for (int col = 0; col < num4; col++) {
                System.out.print("\t "+B[row][col]);
            }
            System.out.println();
        }
        
        
        
    }
    
}
