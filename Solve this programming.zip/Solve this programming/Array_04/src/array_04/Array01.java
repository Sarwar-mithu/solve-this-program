
package array_04;

import java.util.Scanner;


public class Array01 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        double[] number = new double[5];
        double sum = 0;
        System.out.print("Enter any number : ");
        //input
        for (int i = 0; i < 5; i++) {
            number[i] = input.nextDouble();
        }
        
        //output
        for (int j = 0; j < 5; j++) {
            sum = sum + number[j];
        }
        System.out.println("Length : "+number.length);
        System.out.println("The sum is : "+sum);
        
        double avg = sum/number.length;   // 5 deye vag
        System.out.println("Average is : "+avg);
    }
    
}
