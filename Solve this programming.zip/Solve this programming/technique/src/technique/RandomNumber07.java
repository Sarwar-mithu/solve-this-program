
package technique;

import java.util.Random;

public class RandomNumber07 {
    public static void main(String[] args) {
        
       /* Random rand = new Random();
        
        int randomNumber = rand.nextInt(3)+1;
        System.out.println("Random Number : "+randomNumber);
       */
       
       int randomNumber = (int) (Math.random()*2)+1;
        System.out.println("Random Number : "+randomNumber);
    }
    
}
