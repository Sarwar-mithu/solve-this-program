
package technique;
import java.util.Scanner;
//Math class likhe google surch dile hobe
public class MathClass01 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x,y;
        System.out.print("Enter the 'X' value : ");
        x = input.nextInt();
        System.out.print("Enter the 'Y' value : ");
        y = input.nextInt();
        
        int max = Math.max(x, y);  //Math class likhe dot dite hobe
        System.out.println(max+" Maximum number");
        
        int min = Math.min(x, y);
        System.out.println(min+" Minimum number ");
        
        int absolute = Math.abs(y);
        System.out.println("Absolute of 'Y' : "+absolute);
        
        double power = Math.pow(x, y);
        System.out.println(" X to the power Y : "+power);
        
        int round = Math.round(8.4f);
        System.out.println("Round of 8.4 = "+round);
        
        double pi = Math.PI;
        System.out.println(pi);
        
    }
    
}
