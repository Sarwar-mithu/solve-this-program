
package technique;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.util.Locale;


public class DateTimeFormat06 {
    public static void main(String[] args) {
        
        Date date = new Date();
        //System.out.println(date);
        
        DateFormat dateFormat = new SimpleDateFormat("dd/MM/YYYY");
        
        String currentdatFormat = dateFormat.format(date);
        System.out.println("Current Date : "+currentdatFormat);
        
        
        
        LocalTime time = LocalTime.now();
       
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("hh:mm:ss");
        
        String currentTime = time.format(formatter);
        System.out.println("Current Time : "+currentTime);
       
        
    }
    
}
