
package technique;


public class BinaryToDecimal04 {
    
    public static void main(String[] args) {
    
        String binary = "1010";
        Integer decimal = Integer.parseInt(binary, 2);
        System.out.println("Binary to decimal : "+decimal);
        
        String octal = "675";
        decimal = Integer.parseInt(octal, 8);
        System.out.println("Octal to decimal : "+decimal);
        
        
        String hexadecimal = "F";
        decimal = Integer.parseInt(hexadecimal, 16);
        System.out.println("Hexadecimal to decimal : "+decimal);
    
    }
    
    
}
