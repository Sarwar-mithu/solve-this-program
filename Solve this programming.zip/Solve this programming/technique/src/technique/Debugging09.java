
package technique;
/*
1st: Debug jabo ebong click korbo
2nd: new watch click korbo Debug->new watch (sum)
3rd: abar new watch jabo Debug-> new watch  (i)
4th: je line watch korbo thik tar ager line Break korabo
5th: tar porclick kore Debug-> Debug file jabo
6th: Debug file->step over
7th:dekha ses hole continue click korbo 
ar jodi delete korthe hoy ta hole debug output -> delete/delete all
*/

public class Debugging09 {
    public static void main(String[] args) {
        int sum = 0;
        for (int i = 0; i < 10; i++) {
            sum = sum + i;
        }
        System.out.println("Sum is : "+sum);
    }
    
}
