
package technique;

import java.util.Scanner;


public class DecimalToBinary05 {
    public static void main(String[] args) {
        
        Scanner input = new Scanner(System.in);
        int num1;
        
        System.out.print("Enter Decimal Number : ");
        num1 = input.nextInt();
        
        String binary = Integer.toBinaryString(num1);
        System.out.println("Decimal to Binary : "+binary);
        
        System.out.println();
        
        System.out.print("Enter Octal Number : ");
        int num2 = input.nextInt();
        
        String octal = Integer.toOctalString(num2);
        System.out.println("Decimal to Octal : "+octal);
        
        System.out.println();
        
        System.out.print("Enter Hexadecimal(0-15) : ");
        int num3 = input.nextInt(); 
        
        String hex = Integer.toHexString(num3);
        System.out.println("Decimal to Hexadecimal : "+hex.toUpperCase());
        
    }
    
}
