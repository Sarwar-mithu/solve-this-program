
package technique;
import java.util.Arrays;
import java.util.Scanner;

public class ArraySorting02 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num;
        System.out.print("How many array : ");
        num = input.nextInt();
        
        int[] digit = new int[num];
        //10,-3,14,5,30,7 sort to -> -3,5,7,10,14,30
        System.out.print("Enter any number : ");
        for (int i = 0; i < num; i++) {
            digit[i] = input.nextInt();
        }
        System.out.println();
        
        Arrays.sort(digit);
        System.out.print("Acending : ");
        for (int j = 0; j < num; j++) {
            System.out.print(" "+digit[j]);
        }
        System.out.println();
        
        System.out.print("Decending : ");
        for (int j = num-1; j > 0; j--) {
            System.out.print(" "+digit[j]);
        }
        System.out.println();
        
        String[] names = {"Sajada","Medehi","Taher","Salman","mithu"};
        Arrays.sort(names);
        System.out.println("sort : ");
        for (int i = 0; i < 5; i++) {
            System.out.println(names[i]);
        }
    }
    
}
