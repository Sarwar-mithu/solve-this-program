
package superKeyword02;


public class Test {
    public static void main(String[] args) {
        
        Car audi = new Car("White",299,5);
        audi.attribute();
        
    }
    
}
