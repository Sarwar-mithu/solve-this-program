
package oop01;


public class Box {
    
    double height,width,depth;
    double result;
    
    Box(double h, double w,double d){
        height = h;
        width = w;
        depth = d;
    }
    
    
    void displayBox(){
        System.out.println("Height : "+height);
        System.out.println("Width  : "+width);
        System.out.println("Depth  : "+depth);
        System.out.println();
        
         result = height * width * depth;
        System.out.println("Volume Is : "+result);
        System.out.println();
    }
    
    
    
    
}
