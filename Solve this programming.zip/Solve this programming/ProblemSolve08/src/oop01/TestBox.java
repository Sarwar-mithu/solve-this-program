
package oop01;

import java.util.Scanner;


public class TestBox {
    public static void main(String[] args) {
        
     Scanner scan = new Scanner(System.in);
     
        System.out.println("Enter your first box for data ");
        double box1,box2,box3;
        
        System.out.print("Height for 1st box: ");
        box1 = scan.nextDouble();
        System.out.print("Width for 1st box : ");
        box2 = scan.nextDouble();
        System.out.print("Depth for 1st box : ");
        box3 = scan.nextDouble();
        
        System.out.println();
        
        System.out.println("Enter your second box for data ");
        double box4,box5,box6;
        
        System.out.print("Height for 2nd box: ");
        box4 = scan.nextDouble();
        System.out.print("Width for 2nd box : ");
        box5 = scan.nextDouble();
        System.out.print("Depth for 1st box : ");
        box6 = scan.nextDouble();
        System.out.println();
        
        Box firstBox = new Box(box1,box2,box3);
        firstBox.displayBox();
        Box secondBox = new Box(box4,box5,box6);
        secondBox.displayBox();
     
     
     
    }
    
}
