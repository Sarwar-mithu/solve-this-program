
package abstraction04;

import java.util.Scanner;


public class Test {
    public static void main(String[] args) {
        
        Scanner scan = new Scanner(System.in);
        System.out.println("please input the value");
        
        double num1,num2;
        System.out.print("dim1 value : ");
        num1 = scan.nextDouble();
        System.out.print("dim1 value : ");
        num2 = scan.nextDouble();
        
        Shape object;  // abstrat method kono objectject thory kora jai na
        object = new Ractangle(num1,num2);
        object.area();
        object = new Triangle(num1,num2);
        object.area();
        object = new Circle(num1);
        object.area();
    }
    
}
