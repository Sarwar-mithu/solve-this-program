
package abstraction04;


abstract public class Shape {
    
    double dim1, dim2;
    
    Shape(double dim1,double dim2){
        this.dim1 = dim1;
        this.dim2 = dim2;
    }
    
    void displayInformation(){
        System.out.println("Enter dim1 value : "+dim1);
        System.out.println("Enter dim2 value : "+dim2);
    }
    
    abstract void area();
}
