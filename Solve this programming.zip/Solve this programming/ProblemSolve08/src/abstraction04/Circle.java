
package abstraction04;


public class Circle extends Shape {
    
    Circle(double radius){
        
        super(radius,radius);
    
    }
    
    @Override
    void area(){
        double result = Math.PI*dim1*dim2;
        System.out.printf("Area of Circle : %.2f",result);
        System.out.println();
        
        
    }
    
}
