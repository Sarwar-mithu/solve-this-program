
package polymorphism03;


public class Ractangle extends Shape {
    
    double length,width;
    
    Ractangle(double length,double width){
        this.length = length;
        this.width = width;
    }
    
    @Override
    void area(){
        System.out.println("Ractangle length : "+length);
        System.out.println("Ractangle lwidth : "+width);
        System.out.println();
        
        double result = length*width;
        System.out.println("Ractangle : "+result);
        System.out.println();
    }
    
}
