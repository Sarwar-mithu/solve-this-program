
package polymorphism03;


public class Shape {
    
    void area(){
        //return 0;
    }
    
}
