/*
super class object deye sub class ke call dite parbo
Shape s = new Shape();
s = new Ractangle() // sub cls
*/
package polymorphism03;

import java.util.Scanner;


public class Test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        Shape[] s = new Shape[2];
        
        double num1,num2;
        System.out.println("Ractangle value ");
        System.out.print("Length : ");
        num1 = scan.nextDouble();
        System.out.print("Width : ");
        num2 = scan.nextDouble();
        
        //Ractangle ob = new Ractangle(num1,num2);
        s[0] = new Ractangle(num1,num2);
        //ob.area();
        s[0].area();
        
        double num3,num4;
        System.out.println("Triangle value ");
        System.out.print("Base : ");
        num3 = scan.nextDouble();
        System.out.print("Height : ");
        num4 = scan.nextDouble();
        
        
        // Triangle t = new Triangle(num3,num4);
        //t.area();
        
        s[1] = new Triangle(num3,num4);
        s[1].area();
        
        
    }
    
}
