
package polymorphism03;


public class Triangle extends Shape{
    
    double base,height;
    
    Triangle(double base,double height){
        this.base = base;
        this.height = height;
    }
    
    @Override
    void area(){
        System.out.println("Triangle base : "+base);
        System.out.println("Triangle height: "+height);
        System.out.println();
        
        double total = 0.5*base*height;
        System.out.println("Triangle : "+total);
        System.out.println();
        
    }
    
}
