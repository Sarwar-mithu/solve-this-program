
package operator01;
import java.util.Scanner;

public class LogicalOperator04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char ch;
        System.out.print("Enter anay Letter : ");
        ch = input.next().charAt(0);
        
        // logical operator and = &&, or = ||, not = !
        
        if(ch>='a' && ch<='z'){
            System.out.println(ch+" Small letter ");
        }
        else if(ch>='A' && ch<='Z'){
            System.out.println(ch+" Capital letter");
        }
        else{
            System.out.println(ch+" Not a letter");
        }
    }
    
}
