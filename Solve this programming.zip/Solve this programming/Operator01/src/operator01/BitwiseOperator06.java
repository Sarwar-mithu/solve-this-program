
package operator01;
import java.util.Scanner;

public class BitwiseOperator06 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x,y,cal;
        System.out.print("Enter your 'X' value : ");
        x = input.nextInt();
        System.out.print("Enter your 'Y' value : ");
        y = input.nextInt();
        
        cal = x&y; 
        System.out.println(cal+" = Bitwise AND ");
        
        cal = x|y;
        System.out.println(cal+" = Bitwise OR ");
        
        cal = x^y;
        System.out.println(cal+" = Bitwise XOR ");
        
        //Right shift a>>2
        cal = x>>3; //32/2=16,16/2=8,4/2=4 //division korbo
        System.out.println("Right shift = "+cal);
        
        //Left shift a<<2
        cal = x<<3; //Multiplication korbe
        System.out.println(cal+" = Left shift");
    }
    
}
