
package operator01;
import java.util.Scanner;

public class ConditionalOperator05 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int x,y,large;
        System.out.print("Enter the first value : ");
        x = input.nextInt();
        System.out.print("Enter the secand value : ");
        y = input.nextInt();
        
        
        // true ->> x kaj korbe 
        //false ->> y kaj korbe
        large = (x>y) ? x : y;   //tinary operator
        
        System.out.println(large+" Large number ");
         
    }
    
}
