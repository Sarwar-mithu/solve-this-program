
package operator01;


public class UnaryOperator03 {
    
    public static void main(String[] args) {
        /*int x = 10;
        int result;
        
        //+a
        result = +x;    // +x hocce unary operator
        System.out.println("result = "+result);
        
        //-a
        result = -x;
        System.out.println("result = "+result);
        */
        
        //Increment or Decrement
        int x = 25;
        int y;
        
        // postfix increment
        //x++ hole pore jodi kono x pai ta hole x man ek kore barbe
        y = x++; //25
        System.out.println("y = "+y);
        
        y = x;  //26
        System.out.println("y = "+y);
        
        //prefix icrement
        y = ++x; //27
        System.out.println("y = "+y);
        
        y = x;  //27
        System.out.println("y = "+y);
        
        
        
        // decrement x-- or --x hobe
    }
    
}
