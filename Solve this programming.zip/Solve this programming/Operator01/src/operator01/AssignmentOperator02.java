
package operator01;

import java.util.Scanner;


public class AssignmentOperator02 {
    
    public static void main(String[] args) {
      Scanner input = new Scanner(System.in);  
        int x,y;
        System.out.print("Enter the \"x\" Value : ");
        x = input.nextInt();
        
        System.out.print("Enter the \"y\" Value : ");
        y = input.nextInt();
        
        x+=y; // X = x+y(3+2)=5
        System.out.println("X = "+x );
        
        x-=y; // X = x-y=3 // ekhane x = 5 hobe
        System.out.println("X = "+x );
        
        x*=y; // X = x*y=6 //ekhane x=3 hobe
        System.out.println("X = "+x );
        
        x/=y; // X = x/y=3 // ekhane x=6 hobe
        System.out.println("X = "+x );
        
        x%=y; // X = x%y=1 //ekhane x=3 hobe
        System.out.println("X = "+x );
        
    }
    
}
