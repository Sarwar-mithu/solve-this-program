
package operator01;
import java.util.Scanner;

public class ArithmeticOperator01 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num1,num2,result;
        System.out.print("Enter the first value : ");
        num1 = input.nextInt();
        System.out.print("Enter the secand value : ");
        num2 = input.nextInt();
        
        result = num1 + num2;
        System.out.println("Sumation is = "+result);
        
        result = num1 - num2;
        System.out.println("Subtraction is = "+result);
        
        result = num1 * num2;
        System.out.println("Multiplication is = "+result);
        
        //Type casting
        double result2 = (double)num1 / num2; // vag fll
        System.out.println("Div is = "+result2);
        
        result = num1 % num2; //vag ses
        System.out.println("Reminder is = "+result);
        
    }
    
}
