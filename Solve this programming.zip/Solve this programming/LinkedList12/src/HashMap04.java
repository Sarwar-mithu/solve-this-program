
import java.util.HashMap;


public class HashMap04 {
    public static void main(String[] args) {
        
        //put,get
        HashMap<Integer,String> coustomer = new HashMap<Integer,String>();
        
        coustomer.putIfAbsent(101, "Abu Taher");
        coustomer.putIfAbsent(102, "Sagada Akther");
        coustomer.putIfAbsent(103, "Abu Zafor Mehedi");
        coustomer.putIfAbsent(104, "Abu Salman");
        coustomer.putIfAbsent(105, "Sarwar Mithu");
        
        
        System.out.println(coustomer.get(105));
        System.out.println(coustomer.get(104));
        System.out.println(coustomer.get(103));
        System.out.println(coustomer.get(102));
        System.out.println(coustomer.get(101));
    }
    
}
