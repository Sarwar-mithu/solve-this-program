
import java.util.LinkedList;


public class List01 {
    public static void main(String[] args) {
        LinkedList<String> countryName = new LinkedList<String>();
        
        countryName.add("Bangladesh");
        countryName.add("Germany");
        countryName.add("Napal");
        countryName.add("China");
        
        System.out.println(countryName);
    }
    
}
