
import java.util.LinkedList;


public class List02 {
    public static void main(String[] args) {
        
        LinkedList<String> countryName = new LinkedList<String>();
        
        countryName.add("Bangladesh");
        countryName.add("Napal");
        countryName.add("Srilonka");
        countryName.add("Butan");
        countryName.add("India");
        countryName.add(5, "Pakistan");
        countryName.addFirst("London");
        countryName.addLast("Maxico");
        //countryName.remove("India");
        //countryName.remove(3);
        
        for(String country : countryName){
            System.out.println(country);
        }
        
        System.out.println("First elements : "+countryName.getFirst());
        System.out.println("First elements : "+countryName.getLast());
        
        
    }
}




