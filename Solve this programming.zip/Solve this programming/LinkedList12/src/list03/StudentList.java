
package list03;

import java.util.LinkedList;


public class StudentList {
    public static void main(String[] args) {
        
       
        LinkedList<Student> list = new LinkedList<Student>();
        
        Student s1 = new Student("Sarwar mithu","XII",101);
        Student s2 = new Student("Md Abu Jafar Mehedi","XII",102);
        Student s3 = new Student("Md Abu Salman","XII",103);
        Student s4 = new Student("Sajada Akther","XII",104);
        Student s5 = new Student("Md Abu Taher","XII",105);
        
        //adding student to the studentlist
        
        list.add(s1);
        list.add(s2);
        list.add(s3);
        list.add(s4);
        list.add(s5);
        
        //diplayInformation
        for(Student p : list){
            
            System.out.println(p.name+" "+p.className+" "+p.id);
        }
    }
    
}


