
package list03;


public class Student {
   
    String name,className;
    int id;
    
    Student(String name,String className,int id){
        this.name = name;
        this.className = className;
        this.id = id;
    }
    
    void displayInformation(){
        
        System.out.println("Name : "+name);
        System.out.println("Class: "+className);
        System.out.println("S-Id : "+id);
    }
}


