
import java.util.HashSet;


public class HashSet05 {
    public static void main(String[] args) {
        
        HashSet<String> fruitsName = new HashSet<String>();
        
        fruitsName.add("Apple");
        fruitsName.add("Orange");
        fruitsName.add("Mango");
        fruitsName.add("Banana");
        
        System.out.println(fruitsName);
    }
}
