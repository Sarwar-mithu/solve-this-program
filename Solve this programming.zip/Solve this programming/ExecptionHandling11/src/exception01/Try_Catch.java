/*
serial onujai asbe 1=2=3=4=5=6 etc;
chotto theke boro te jabe/ kono vabhei boro theke chotto te asbe na

ArithmeticException->ArrayIndexOutOfBoundsException -> Exception
*/
package exception01;


public class Try_Catch {
    public static void main(String[] args) {
       
       try{
           
            int x = 10;
            int y = 0;
        
        int result = x/y;
        System.out.println("Result : "+result);
       }catch(ArrayIndexOutOfBoundsException e2){
           System.out.println("Exception : "+e2);
       }
       catch(ArithmeticException e1){
           System.out.println("Exception : "+e1);
       }
       catch(Exception e3){
           System.out.println("Exception : "+e3);
       }
       
       
       finally{
           System.out.println("last line of the program");
       }
       
        
        
    }
}






