
package problemsolve;

import java.util.Scanner;


public class ArmstrongNumber15 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int num,temp,reminder;
        int sum = 0;
        System.out.print("Enter any number 153 : ");
        num = input.nextInt();
        temp = num;
        while(temp!=0){
            reminder = temp % 10;
            sum = sum + reminder*reminder*reminder;
            temp = temp / 10;
        }
        if(sum==num){
            //input 153 aramstrong
            System.out.println(sum+" Is armstrong number ");
        }
        else{
            System.out.println(sum+" Not a armstrong ");
        }
    }
    
}
