
package problemsolve;
import java.util.Scanner;

public class PrimeNumber10 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int m,n,totalPrime = 0;
        int count = 0;
        System.out.print("Enter initial Number : ");
        m = input.nextInt();
        System.out.print("Enter ending Number : ");
        n = input.nextInt();
        
        for(int i=m; i<=n; i++){ 
            for(int j=2; j<=i-1; j++){
                if(i%j==0)
                {
                    count++;
                    break;
                }
            }
            if(count==0){
                System.out.println(i);
                totalPrime++;
            }
                count = 0;
            
        }
        System.out.println("Total prime number : "+totalPrime);
    }
    
}
