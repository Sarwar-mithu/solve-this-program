
package problemsolve;

import java.util.Scanner;


public class Series07 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int n;
        int sum = 0;
        System.out.print("Enter ending number : ");
        n = input.nextInt();
        
        for(int i = 1;i<=n;i=i+2){
            sum = sum+i*i;
            System.out.print(i+" * "+i+","+"  ");
        }
        System.out.println();
        System.out.println("The sum is : "+sum );
    }
    
}
