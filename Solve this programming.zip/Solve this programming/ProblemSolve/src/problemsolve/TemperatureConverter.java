
package problemsolve;

import java.util.Scanner;


public class TemperatureConverter {
    
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double celsius,fahrenheit;
        System.out.print("Enter Celsius value : ");
        celsius = input.nextDouble();
        //celsius to fahrenheit converter
        fahrenheit = 1.8 * celsius + 32; // 9/5*c+32  Formula
        
        System.out.println("Fahrenheit is : "+fahrenheit);
        
    }
    
}
