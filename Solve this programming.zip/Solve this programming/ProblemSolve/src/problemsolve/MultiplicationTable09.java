
package problemsolve;
import java.util.Scanner;

public class MultiplicationTable09 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num,i;
        System.out.print("Enter any number : ");
        num = input.nextInt();
        for(i=1;i<=10;i++){
            int mul = num*i;
            System.out.println(num+"*"+i+" = "+mul);
        }
    }
    
}
