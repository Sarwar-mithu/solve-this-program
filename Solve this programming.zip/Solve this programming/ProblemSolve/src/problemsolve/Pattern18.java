
package problemsolve;

import java.util.Scanner;


public class Pattern18 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num;
        System.out.print("Enter any number : ");
        num = input.nextInt();
        
        for(int row = 1; row <= num; row++){
            for(int col = 1; col <= row; col++){
                System.out.printf(" "+"%c",col+64); // ASCII CODE A->64 THEKE 
        }
            System.out.println();
    }
    
    }
}