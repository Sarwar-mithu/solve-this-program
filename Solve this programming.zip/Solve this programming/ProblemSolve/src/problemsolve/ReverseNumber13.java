
package problemsolve;

import java.util.Scanner;


public class ReverseNumber13 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num,temp,reminder;
        int sum = 0;
        System.out.print("123 to 321 reverse number = ");
        num = input.nextInt();
        temp = num;
        
        while(temp!=0){
            reminder = temp % 10;
            sum = sum * 10 + reminder;
            temp = temp / 10;
        }
        System.out.println("Output 123 to 321 reverse number : "+sum);
        
    }
    
}
