
package problemsolve;
import java.util.Scanner;

public class PrimeNumber09 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num;
        int count = 0;
        System.out.print("Enter Initial Number : ");
        num = input.nextInt();
        
        
        for(int i=2;i < num;i++){
            if(num%i==0){
                count++;
                break;
            }
        }
        if(count==0){
            System.out.println(num+" prime number ");
        }
        else{
            System.out.println(num+" Not a prime number ");
        }
    }
    
}
