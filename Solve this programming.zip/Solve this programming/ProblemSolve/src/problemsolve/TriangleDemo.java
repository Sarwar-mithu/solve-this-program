
package problemsolve;
import java.util.Scanner;

public class TriangleDemo {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        double base,height,area;
        System.out.print("Base value : ");
        base = input.nextDouble();
        System.out.print("Height value : ");
        height = input.nextDouble();
        
        area = 0.5*base*height;
        System.out.println("Area of triangle : "+area);
        
        //circle
        double radius,cal;
        System.out.print("Enter Radius : ");
        radius = input.nextDouble();
        
        cal = 3.1416*radius*radius;
        System.out.println("Area of circle : "+cal);
        
    }
    
}
