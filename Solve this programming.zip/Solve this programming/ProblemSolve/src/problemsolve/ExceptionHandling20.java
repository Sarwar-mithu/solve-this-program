
package problemsolve;
/*
int count = 1;
do{
//full code
count = 2;
}while() deye o kora jabe

*/

import java.util.Scanner;


public class ExceptionHandling20 {
    public static void main(String[] args) {
        
        
        while(true){
            
             try{
            
            Scanner scan = new Scanner(System.in);
        
        int num1,num2;
        System.out.print("Please enter num1 : ");
        num1 = scan.nextInt();
        
        System.out.print("Please enter num2 : ");
        num2 = scan.nextInt();
      
        int result =  num1/num2;
        System.out.println("Result : "+num1+"/"+num2+" = "+result);
            
        }catch(Exception e){
            System.out.println("Exception : "+e);
            System.out.println(" You must enter Integer.please try again");
        }
            
        }
       
        
        
        
    }
    
}
