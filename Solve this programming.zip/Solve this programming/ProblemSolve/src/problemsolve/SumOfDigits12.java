
package problemsolve;

import java.util.Scanner;


public class SumOfDigits12 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int num,sum = 0;
        int reminder;
        System.out.print("Enter any integer Number : "); //input 254
        num = input.nextInt();
        int temp = num;
        while(temp!=0){
            reminder = temp%10;
            sum = sum + reminder;
            temp = temp / 10;
        }
        System.out.println("Sum of digit : "+sum);
        
        
    }
    
}
