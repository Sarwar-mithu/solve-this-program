
package problemsolve;
import java.util.Scanner;

public class VowelConsonant04 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        char ch;
        System.out.print("Enter any letter : ");
        ch = input.next().charAt(0); // single charcter jonno ai vabhe nite hoy
        
        if(ch=='a' || ch == 'e' || ch == 'i' || ch =='o' || ch == 'u'){
            System.out.println(ch+" Is Vowel");
        }
        else{
            System.out.println(ch+" Is Consonant");
        } 
    }
    
}
