
package problemsolve;

import java.util.Scanner;


public class PalindromeNumber14 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        
        int num,temp,reminder;
        int sum = 0;
        
        System.out.print("121 to 121 is palindrome : ");
        num = input.nextInt();
        temp = num;
        
        while(temp!=0){
            reminder = temp % 10;
            sum = sum * 10 + reminder;
            temp = temp / 10;
    }
        if(num==sum){  // 121 to 121 palindorme
            System.out.println(sum+" Is palindrome number");
        }
        else{
            System.out.println(sum+" Not a palindrome number");
        }
    
 }
}
    
