
package problemsolve;

import java.util.Scanner;
public class LoopSum06 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int sum = 0;
        int m,n;
        System.out.print("Enter Initial number : ");
        m = input.nextInt();
        System.out.print("Enter Ending  number : ");
        n = input.nextInt();
        
        for(int i=m;i<=n;i++){
            if(i%2==0){
                sum = sum+i;
                System.out.print(" "+i);
            }
        }
        System.out.println();
        System.out.println("The sum is : "+sum);
    }
    
}
