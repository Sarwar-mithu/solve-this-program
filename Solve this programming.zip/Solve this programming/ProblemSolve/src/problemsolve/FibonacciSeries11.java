
package problemsolve;

import java.util.Scanner;


public class FibonacciSeries11 {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        int first = 0;
        int second = 1;
        int x,fibo;
        System.out.print("How many fibonacci : ");
        x = input.nextInt();
        System.out.print(first+" "+second);
        
        
        for(int i =3;i<=x;i++){
            fibo = first + second;
            System.out.print(" "+fibo);
            first = second;
            second = fibo;
        }
        System.out.println();
    }
}
