
package instance_variable14;


public class Test {
    public static void main(String[] args) {
        InstanceVariable box = new InstanceVariable(10,10,10);
        box.displayBox();
        InstanceVariable box2 = new InstanceVariable(20,30,10);
        box2.displayBox();
        
    }
    
}
