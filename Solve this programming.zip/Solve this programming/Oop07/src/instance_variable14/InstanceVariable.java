
package instance_variable14;


public class InstanceVariable {
    double height,width,depth; //instance variable
    
    InstanceVariable(double height,double width,double depth){
        this.height = height;  //instance variable = local variable ekai hole this keyword likthe hoy
        this.width = width;
        this.depth = depth;
    }
    
    void displayBox(){
        double vol = height*width*depth;
        System.out.println("Volume is : "+vol);
    }
    
}
