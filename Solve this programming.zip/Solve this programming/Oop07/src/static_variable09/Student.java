
package static_variable09;


public class Student {
    
    //Object charai call dite parbo
    //Class r maddhome print ba call dite parbo
    static String universiytName = "Eastern university";
    
}
