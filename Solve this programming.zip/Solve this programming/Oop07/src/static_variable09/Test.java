
package static_variable09;


public class Test {
    
    public static void main(String[] args) {
        
        
        System.out.println("University : "+Student.universiytName);
    }
    
}
