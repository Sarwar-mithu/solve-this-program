
package method_overloading15;


public class Test {
    public static void main(String[] args) {
        
        
        Overloading ob = new Overloading();
        ob.add();
        ob.add(5,10);
        ob.add(6.5,5.5);
        ob.add(5,10,20);
        
        
    }
    
}
