
package method02;


public class Teacher {
    
    String name,gender;
    int phone;
    
    void displayInformation(){
        System.out.println("Name   : "+name);
        System.out.println("Gender : "+gender);
        System.out.println("Phone  : "+phone);
    }
    
}
