
package method02;

import java.util.Scanner;


public class test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        Teacher teacher1 = new Teacher();
        Teacher teacher2 = new Teacher();
        Teacher teacher3 = new Teacher();
        
        System.out.println("First teacher Data entry : ");
        System.out.print(" Enter your name : ");
        teacher1.name = scan.nextLine();
        System.out.print("Enter your gender: ");
        teacher1.gender = scan.nextLine();
        System.out.print("Enter your phone : ");
        teacher1.phone = scan.nextInt();
        
        System.out.println();
        
        
        System.out.println("Second teacher Data entry : ");
        teacher2.name = "Abu Salman";
        teacher2.gender = "Male";
        teacher2.phone = 8797;
        
        System.out.println("Third teacher Data entry : ");
        teacher3.name = "Abu Jafor Mehedi";
        teacher3.gender = "Male";
        teacher3.phone = 23;
        
        
        teacher1.displayInformation();
        System.out.println();
        teacher2.displayInformation();
        System.out.println();
        teacher3.displayInformation();
    }   
    
}
