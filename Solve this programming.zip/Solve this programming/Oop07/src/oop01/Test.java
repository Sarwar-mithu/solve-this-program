
package oop01;




public class Test {
    public static void main(String[] args) {
        
        Teacher teacher1 = new Teacher();
     
        teacher1.name = "Sarwar Mithu";
        teacher1.gender = "Male";
        teacher1.phone = 1964626938;
        
        System.out.println("Name   : "+teacher1.name);
        System.out.println("Gender : "+teacher1.gender);
        System.out.println("Phone  : "+teacher1.phone);
        
        
        System.out.println("\n");
        
        
        Teacher teacher2 = new Teacher();
        
        teacher2.name = "Abu Salman";
        teacher2.gender = "Male";
        teacher2.phone = 19626938;
        
        System.out.println("Name   : "+teacher2.name);
        System.out.println("Gender : "+teacher2.gender);
        System.out.println("Phone  : "+teacher2.phone);
    }
    
}
