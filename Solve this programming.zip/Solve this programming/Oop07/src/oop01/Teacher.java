
package oop01;

import java.util.Scanner;


public class Teacher {
    String name,gender;
    int phone;
    
  
    
  
    
    
}
