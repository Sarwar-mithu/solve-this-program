
package overloding_constructor06;


public class Teacher {
    
    String name,gender;
    int phone;
    
    Teacher(){
        System.out.println("No Information ");
    }
    
    Teacher(String n,String g){
        name = n;
        gender = g;
    }
    
    Teacher(String x,String y,int z){
        name = x;
        gender = y;
        phone = z;
    }
    
    void displayInformation(){
        System.out.println("Name  : "+name);
        System.out.println("Gender: "+gender);
        System.out.println("Phone : "+phone);
        System.out.println();
    }
    
}
