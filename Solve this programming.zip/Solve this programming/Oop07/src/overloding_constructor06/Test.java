
package overloding_constructor06;


public class Test {
    public static void main(String[] args) {
        
        Teacher teacher1 = new Teacher();
        
        Teacher teacher2 = new Teacher("Salman","Male");
        teacher2.displayInformation();
        
        Teacher teacher3 = new Teacher("Mehedi","Male",1827610036);
        teacher3.displayInformation();
    }
    
}
