
package parametrizedMethod03;

import java.util.Scanner;


public class Test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        Teacher teacher1 = new Teacher();
        Teacher teacher2 = new Teacher();
        
        
        
        teacher1.setInformation("sarwar mithu", "male", 1234);
        teacher1.displayInformation();
        System.out.println();
        teacher2.setInformation("Abu salman", "Male", 234);
        teacher2.displayInformation();
        
    }
    
}
