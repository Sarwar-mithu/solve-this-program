
package constructorDefault05;


public class Test {
    public static void main(String[] args) {
        
        Teacher teacher1 = new Teacher("Sajada Akther","Female",1797999724);
        teacher1.displayInformation();
        
        
        Teacher teacher2 = new Teacher("Abu Taher","Male",1633782425);
        teacher2.displayInformation();
        
        Teacher teacher3 = new Teacher();
        teacher3.displayInformation();
    }
}
