
package call_by_value16;


public class CallByValueTest {
    public static void main(String[] args) {
        
        CallByValue ob = new CallByValue();
        int x = 20;
        System.out.println("X befor call : "+x);
        
        //call deoar poro value change hobe na
        ob.change(x);
        System.out.println("X after call : "+x);
    }
    
}
