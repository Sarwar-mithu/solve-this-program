
package call_by_value16;


public class CallByValue {
    
    void change(int i){
        i = 14;
    }
    
}
