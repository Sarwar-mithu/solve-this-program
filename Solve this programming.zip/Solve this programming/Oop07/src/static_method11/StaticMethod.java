
package static_method11;


public class StaticMethod {
    
    //non-static method
    void display(){
        System.out.println("I am not static method ");
    }
    
    
    // static method
    static void display2(){
        System.out.println("I am static method ");
    }
    
    
}
