
package static_method11;


public class Test {
    
    public static void main(String[] args) {
        //non static method object thory korthe hoy
        StaticMethod s1 = new StaticMethod();
        s1.display();
        
        //static method kono object thory korthe hoy na
        StaticMethod.display2();
    }
    
}
