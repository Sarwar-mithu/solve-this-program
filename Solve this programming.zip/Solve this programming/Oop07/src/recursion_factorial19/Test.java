
package recursion_factorial19;

import java.util.Scanner;


public class Test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        int num;
        System.out.print("Enter any Integer number : ");
        num = scan.nextInt();
        
        Recursion ob = new Recursion();
        int result = ob.fact(num);
        System.out.println("Factorial of : "+result);
        
        
    }
    
}
