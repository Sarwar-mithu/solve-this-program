
package types_of_variable13;


public class Test {
    public static void main(String[] args) {
        
        VariableTypes ob1 = new VariableTypes("Sarwar mithu",497192);
        ob1.displayInformation();
    }
    
}
