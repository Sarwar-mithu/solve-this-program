
package types_of_variable13;


public class VariableTypes {
    
    String name;  //Instance variable
    int id;       //Instance variable
    static String universityName = "Eastern University"; // static variable
    
     
                  // local variable
    VariableTypes(String n,int i){
        
        name = n;
        id = i;
    }
    
    
    void displayInformation(){
        System.out.println("Student name : "+name);
        System.out.println("Student id   : "+id);
        System.out.println("University   : "+universityName);
    }
    
}
