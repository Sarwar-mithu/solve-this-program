
package constructorMethod04;

public class Teacher {
    
    String name,gender;
    int phone;
    
    //constructor method (Special method)
    //parametrized constructor
    Teacher(String n,String g,int ph){
        name = n;
        gender = g;
        phone = ph;
        
    }
    
    
    void displyInformation(){
        System.out.println("Name  : "+name);
        System.out.println("Gender: "+gender);
        System.out.println("Phone : "+phone);
        System.out.println();
    }
}
