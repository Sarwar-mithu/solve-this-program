
package constructorMethod04;


public class Test {
    public static void main(String[] args) {
        
        Teacher teacher1 = new Teacher("Sajada Akther","Female",1797999724);
        teacher1.displyInformation();
        
        Teacher teacher2 = new Teacher("Abu Taher","Male",1633782425);
        teacher2.displyInformation();
    }
    
}
