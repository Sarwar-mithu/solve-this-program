
package call_by_reference17;


public class CallByReferenceTest {
    public static void main(String[] args) {
        
        CallByReference c1 = new CallByReference();
        c1.name = "Abu Taher";
        System.out.println("Before calling : "+c1.name);
        
        
        // change hoye jabe 
        //c1=>r2 hobe (reference value ta kei call dibe)
        c1.change(c1);
        System.out.println("After calling : "+c1.name);
    }
    
}
