
package call_by_reference17;

/**

 */
public class CallByReference {
    
    String name;
    void change(CallByReference r2){
        r2.name = "Sajada Akther";
    }
    
    
}
