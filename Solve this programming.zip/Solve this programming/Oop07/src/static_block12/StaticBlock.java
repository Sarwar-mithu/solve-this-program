
package static_block12;


public class StaticBlock {
    
   static int id;
   static String name;
    
    static{
        id = 163410020;
        name = "Sarwar Mithu";
    }
    
    
    static void displayInformation(){
        System.out.println("Student id  : "+id);
        System.out.println("Student name: "+name);
    }
    
}
