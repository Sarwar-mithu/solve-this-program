
package static_block12;


public class Test {
    public static void main(String[] args) {
        
        StaticBlock.displayInformation();
    }
    
}
