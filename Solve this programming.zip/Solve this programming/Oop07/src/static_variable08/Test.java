
package static_variable08;


public class Test {
    public static void main(String[] args) {
        
        Student student1 = new Student("Sarwar mithu",163410020);
        student1.displayInforamtion();
        
        Student student2 = new Student("Abu Salman",163410021);
        student2.displayInforamtion();
    }
    
}
