
package static_variable08;


public class Student {
    
    String name;
    int id;
    static String universityName = "Eastern University";
    
    Student(String n,int i){
        name = n;
        id = i;  
    }
    
    void displayInforamtion(){
        System.out.println("Student name: "+name);
        System.out.println("Student id : "+id);
        System.out.println("University : "+universityName);
        System.out.println();
    }
    
}
