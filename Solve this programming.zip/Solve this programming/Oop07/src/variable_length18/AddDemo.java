
package variable_length18;


public class AddDemo {
    /*
    void add(int a,int b){
        System.out.println("Sum is : "+(a+b));
    }
    
    void add(int a,int b,int c){
        System.out.println("Sum is : "+(a+b+c));
    }
    void add(int a,int b,int c,int d){
        System.out.println("Sum is : "+(a+b+c+d));
    }
    */
    
    // method bar bar call na deye eke bare kajti sompurnno korthe pari
    
    void add(int...num){
        int sum = 0;
         
        for(int x : num){
            sum = sum + x;
        }
        System.out.println("Sumation is : "+sum);
    }
    
}
