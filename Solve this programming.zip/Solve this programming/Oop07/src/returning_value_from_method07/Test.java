
package returning_value_from_method07;

import java.util.Scanner;


public class Test {
    public static void main(String[] args) {
        Scanner scan = new Scanner(System.in);
        
        ReturningValue digit = new ReturningValue();
        System.out.print("Enter any Integer number : ");
        int num = scan.nextInt();
        int result = digit.squre(num);
        System.out.println("Multifai this number : "+result);
        
        
    }
    
}
