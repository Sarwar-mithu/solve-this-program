
package returning_value_from_method07;


public class ReturningValue {
    
    int squre(int value){
        return value*value;
    }
    
}
