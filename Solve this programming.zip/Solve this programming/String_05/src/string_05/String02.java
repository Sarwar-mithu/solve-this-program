/*
 concat()
toUpperCase()
toLowerCase()
startsWith()
endsWith()
 */
package string_05;


public class String02 {
    public static void main(String[] args) {
        String firstName = "Sarwar";
        String lastName = new String(" mithu");
        
        
        String fullName = firstName.concat(lastName);
        System.out.println("Full name : "+fullName);
        
         String upperName = fullName.toUpperCase();
         System.out.println("Capital latter : "+upperName);
         
         String lowerName = fullName.toLowerCase();
         System.out.println("Small letter : "+lowerName);
         
         boolean b = firstName.startsWith("S");
         System.out.println("Start with name of first letter : "+b);
         
         boolean c = firstName.endsWith("r");
         System.out.println("End with name of last letter : "+c);
         
         //string array
         String[] names = {"mithu","Sarwar","Mirza"};
         for(String x : names){
             
             System.out.println(x);
         }
    }
    
}
