
package string_05;

public class String03 {
    public static void main(String[] args) {
        String spaceRemove = "     Bangladesh is my country    ";
        System.out.println(spaceRemove);
        
        String country = spaceRemove.trim();
        System.out.println(country);
        
        
        char ch = country.charAt(0);
        System.out.println("Zero Index : "+ch);
        
        int value = country.codePointAt(0);
        System.out.println("ASCII code in index : "+value);
        
        int position = country.indexOf("is");
        System.out.println("Position any letter or word in index: "+position);
        
        
        position = country.lastIndexOf("n");
        System.out.println(" Whatevar, last index of n : "+position);
        
        
    }
    
}
