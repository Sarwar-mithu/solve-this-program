/*

 */
package string_05;


public class String04 {
    public static void main(String[] args) {
        String s1 = " this is my conuntry";
        
        System.out.println(s1);
        
        String s2 = s1.replace('i','Q');
        System.out.println("Replace letter : "+s2);
        
        String[] s3 = s1.split(" "); //jekhanei space pabe sei kahne vag hoye jabe 
        for(String x : s3){
            System.out.println(x);
        }
        
    }
    
}
