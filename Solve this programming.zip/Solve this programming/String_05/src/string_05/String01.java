/*
length()
equals()
equalsIgnoreCase()
contains()
isEmpty()

*/
package string_05;


public class String01 {
    public static void main(String[] args) {
        String s1 = "Sarwar mithu";
        String s2 = new String("sarwar mithu");
        
        System.out.println("S1 = "+s1);
        System.out.println("S2 = "+s2);
        
        int len = s1.length();
        System.out.println("Length of S1 : "+len);
        
        if(s1.equalsIgnoreCase(s2)){
            System.out.println("Equals");
        }
        else{
            System.out.println("Not equals");
        }
        
        
        boolean con = s1.contains("mithu");
        System.out.println("match this name : "+con);
        
        
        boolean b = s1.isEmpty();
        System.out.println("S1 Empty : "+b);
    }
    
}
