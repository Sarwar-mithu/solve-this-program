
package stringBuilder;


public class StringBuilder01 {
    public static void main(String[] args) {
        StringBuilder str = new StringBuilder("Sarwar");
        
        str.append(" Mithu ");
        str.append(25);
        System.out.println(str);
        
        
        str.reverse();
        System.out.println(str);
        
        str.delete(2, 5);
        System.out.println(str);
    }
    
}
