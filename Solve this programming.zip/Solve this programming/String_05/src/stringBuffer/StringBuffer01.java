
package stringBuffer;


public class StringBuffer01 {
    public static void main(String[] args) {
        StringBuffer sb = new StringBuffer("Sarwar ");
        
        System.out.println(sb);
        
        sb.append(" mithu ");
        sb.append(25);
        System.out.println("full name : "+sb);
        
        //sb.reverse();
        //System.out.println("Reverse : "+sb);
        
        sb.delete(8, 14);
        System.out.println("delete : "+sb);
        
        sb.setLength(6);
        System.out.println("Print index 6 : "+sb);
        
        
    }
    
}
