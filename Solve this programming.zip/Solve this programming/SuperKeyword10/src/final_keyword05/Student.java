
package final_keyword05;


public class Student extends University {
    
    void display2(){
        System.out.println("Student info");
    }
    
}
