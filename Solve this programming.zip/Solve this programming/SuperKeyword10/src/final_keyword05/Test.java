
package final_keyword05;


public class Test {
    public static void main(String[] args) {
        
        Student s1 = new Student();
        s1.diplay();
        s1.display2();
    }
    
}
