
package final_keyword05;


public class University {
    
    final void diplay(){
        System.out.println("University info");
    }
    
}
