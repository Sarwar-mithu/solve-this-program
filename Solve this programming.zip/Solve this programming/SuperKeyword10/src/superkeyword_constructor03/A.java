
package superkeyword_constructor03;


public class A {
    A(){
        System.out.println("A's constructor");
    }
    
}
