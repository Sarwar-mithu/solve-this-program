
package superkeyword_constructor03;


public class Test {
    public static void main(String[] args) {
        B ob = new B();
    }
    
}
