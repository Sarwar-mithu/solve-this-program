
package superkeyword_constructor03;


public class B extends A {
    B(){
        super();
        System.out.println("B's constructor");
    }
    
}
