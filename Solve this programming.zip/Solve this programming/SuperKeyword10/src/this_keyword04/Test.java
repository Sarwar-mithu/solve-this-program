
package this_keyword04;


public class Test {
    public static void main(String[] args) {
        
        Person p1 = new Person("Sajada Akther",55);
        p1.displayInformation();
        
        Person p2 = new Person("Abu Taher",60,"Black");
        p2.displayInformation();
    }
    
}
