
package superkey_method02;
/*
override method a jonno ekai method hole super keyword 
deye amara call dite pari
*/
public class B extends A{
    
    @Override
    void display(){
        super.display();
        System.out.println("Inside B class"); 
    }
    
}
