
package superkey_method02;


public class A {
    void display(){
        System.out.println("Inside A class ");
    }
}
