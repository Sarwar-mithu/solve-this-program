
package superkey_word01;


public class A {
    
    int x = 10;
    
}
