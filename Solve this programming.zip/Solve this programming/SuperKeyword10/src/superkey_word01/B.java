
package superkey_word01;

public class B extends A {
    int x = 5;
    
    void display(){
        //System.out.println(x); // print x = 5;
        
        System.out.println(super.x);
    }
}
