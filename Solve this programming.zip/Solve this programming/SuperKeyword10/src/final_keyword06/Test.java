
package final_keyword06;


public class Test {
    
    public static void main(String[] args) {
        
        University ob = new University();
        ob.display();
    }
    
}
