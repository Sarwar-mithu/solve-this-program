
package final_keyword06;


public class University {
    
    final String UNIVERSITY_NAME = "Eastern university";
    //int fees = 25000;
    final int fees;  // balank final variable
    
    
    /*
    static final int fees; //static final variable
    static{
        fees = 26000;
    }
    */
    
    University(){
        fees = 35000;
    }
    void display(){
        System.out.println(UNIVERSITY_NAME);
        System.out.println(fees);
    }
    
}
