
package filedemo13;

import java.io.File;


public class File01 {
    public static void main(String[] args) {
        
        //File dir = new File("C:/Users/Nasir2/Desktop/Person");  // ami location o select kore dite parbo
        File dir = new File("Student");
        
        dir.mkdir(); // directory will be created
        
        String dirLocation = dir.getAbsolutePath(); // amar folder ta koi ace tar jonno
        System.out.println(dirLocation);
        System.out.println(dir.getName());
        
        /*if(dir.delete()){
            System.out.println(dir.getName()+" folder has been deleted");
        }
        */
        
    }
    
}


