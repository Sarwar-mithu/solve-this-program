
package filedemo13;

import java.io.File;


public class File02 {
    public static void main(String[] args) {
        
        File dir = new File("university");
        dir.mkdir();
        
        String path = dir.getAbsolutePath();
        
        
        //File file1 = new File("student.txt");
        File file1 = new File("C:/Users/Nasir2/Desktop/Solve this programming/FileDemo13/university/student.txt");
        //File file1 = new File(path+"student.txt");
        //File file2 = new File("teacher.txt");
        File file2 = new File("C:/Users/Nasir2/Desktop/Solve this programming/FileDemo13//university/teacher.txt");
        //File file2 = new File(path+"teacher.txt");
        try{
            file1.createNewFile(); 
            file2.createNewFile();
            System.out.println("Files are cteated");
        }catch(Exception e){
            System.out.println(e);
        }
        
        if(file1.exists()){
            System.out.println("File exists");
        }
        
        /*
        file2.delete();
        if(file2.exists()){
            System.out.println("file exits");
        }else{
            System.out.println("file does not exist");
        }
        */
        
    }
    
}
