
package filedemo13;

import java.io.File;
import java.util.Scanner;


public class FileRead04 {
    public static void main(String[] args) {
        
        try{
            File file = new File("C:/Users/Nasir2/Desktop/Solve this programming/FileDemo13/university/student.txt");
            
            Scanner scan = new Scanner(file);
            
            while(scan.hasNext()){
                String id = scan.next();
                String name = scan.next();
                
                System.out.println("Id : "+id +" Name: "+name);
            }
            
            scan.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
    
}
