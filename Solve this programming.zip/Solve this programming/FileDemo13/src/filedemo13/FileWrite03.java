
package filedemo13;

import java.util.Formatter;
import java.util.Scanner;


public class FileWrite03 {
    public static void main(String[] args) {
        
        String id, name;
        try{
            
            Formatter formatter = new Formatter("C:/Users/Nasir2/Desktop/Solve this programming/FileDemo13/university/student.txt");
            
            /*
            Scanner scan = new Scanner(System.in);
            
            System.out.print("How many student : ");
            int num = scan.nextInt();
            
            for (int i = 1; i <= num; i++) {
                System.out.print("Student id and name : ");
                id = scan.next();
                name = scan.next();
                formatter.format("%s %s\r\n", id,name);
            }
            */
            
            formatter.format("%s %s\r\n", "102","Salaman ");
            formatter.format("%s %s\r\n", "103","Mehedi ");
            
            formatter.close();
        }catch(Exception e){
            System.out.println(e);
        }
    }
}
