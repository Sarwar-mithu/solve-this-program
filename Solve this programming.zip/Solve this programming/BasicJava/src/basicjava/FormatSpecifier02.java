
package basicjava;


public class FormatSpecifier02 {
    public static void main(String[] args) {
        boolean b = true;
        char c = 's';
        short s = 32677;
        int i = 126587;
        float f = 10.2f;
        double d = 20.34566;
        
        System.out.printf("Boolean b = %b\n",b);
        System.out.printf("Character c = %c\n",c);
        System.out.printf("Short s = %d\n",s);
        System.out.printf("Integer i = %d\n",i);
        System.out.printf("Float f = %f\n", f);
        System.out.printf("Double d = %.2f\n", d);
    }
    
}
