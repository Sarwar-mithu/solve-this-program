
package basicjava;


public class EscapeSequence01 {
    
    public static void main(String[] args) {
       /* System.out.println("Md Golam Sarwar");
        System.out.println("Id = 163410020");
        System.out.println("Bsc in CSE");
       */
       //Escape Sequence
       System.out.println(" Md Golam Sarwar \n Id = 163410020 \n BSC in CSE ");
    }
}
